# Nodemcu_getpost
Assista ao tutorial sobre esse projeto no www.youtube.com/arduinobrasil Na playlist NODEMCU
